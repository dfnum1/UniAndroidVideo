# Unity Android Camera Demo

This demo use Camera1 api.

![](./screenshot.png)



## Build Android Plugin

cd to `AndroidPlugin` folder and run:

```
./gradlew buildAARForUnity
```

